// This tool is distributed under a BSD licence. A copy of this
// should have been included with this file.
//
// Copyright (c) 2011, nils


package com.mwr.wcr;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PathPermission;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.mwr.wcr.NanoHTTPD.Response;

public class ContentHTTPD extends NanoHTTPD {

	private String version = "alpha";
	private String[] quickhelp = {"<a href=\"/info\">info</a> displays information about the device</a>",
			"<a href=\"/list\">list</a> lists all registered content providers.",
			"<a href=\"/query\">query</a> queries a specific content provider.",
			"<a href=\"/read\">read</a> tries to read a remote file descriptor using the openInputStream() method.",
			"<a href=\"/read2\">read2</a> tries to read a remote file descriptor using the openFileDescriptor() method.",
			"<a href=\"/insert\">insert</a> inserts into a given content provider.",
			"<a href=\"/update\">update</a> attempts to update a row in a given content provider."
			};
		
	
	ContentResolver cr = null;
	private PackageManager pm;
	
	public ContentHTTPD(int port, ContentResolver cr, PackageManager pm) throws IOException {
		super(port);
		this.cr = cr;
		this.pm = pm;
	}

	public Response serve( String uri, String method, Properties header, Properties parms, Properties files ) {
		Response resp = null;
		if(uri.equals("/")) {
			resp = getUsage();
		} else if(uri.equals("/info")) {
			resp = getInfo();
		} else if(uri.equals("/query")) {
			resp = execQuery(parms);
		} else if(uri.equals("/list")) {
			resp = list(parms);
		} else if(uri.equals("/read")) {
			resp = read(parms);
		} else if(uri.equals("/read2")) {
			resp = read2(parms);
		} else if(uri.equals("/insert")) {
			resp = insert(parms);
		} else if(uri.equals("/update")) {
			resp = update(parms);
		} else {
			resp = new Response(HTTP_NOTFOUND, MIME_PLAINTEXT, "not found");
		}
		return resp;
	}
	
	private Response updateUsage() {
		String usage = "Updates a row into the content provider.\n";
		usage += "Following Parameters are supported:\n";
		usage += "a: defines the authority to query (required)\n";
		usage += "path0..n: elements of the path. Will be used to construct the URI as follows: content://a/path0/path1/../pathn\n";
		usage += "value0..n: values to be inserted into the content provider. The key/value pair is comma separated. E.g. value0=_id,6\n";
		usage += "where: the where clause. E.g. _id=5\n";
		usage += "arg0..n: elements of the selectionArgs argument.\n";
		return new Response(this.HTTP_OK, MIME_PLAINTEXT, usage);
	}

	private Response update(Properties parms) {
		Uri uri = getUri(parms);
		if(uri == null) return updateUsage();
		try {
			String[] values = getArgs("value",parms);
			ContentValues cvs = new ContentValues();
			for(String v: values) {
				String[] pair = v.split("=");
				cvs.put(pair[0], pair[1]);
			}
			String where = parms.getProperty("where");
			String[] selectionArgs = getArgs("arg",parms);
			int rc = this.cr.update(uri, cvs, where, selectionArgs);
			String output = "rc: " + rc;
			
			return new Response(HTTP_OK, MIME_PLAINTEXT, output);
		} catch (Exception e) {
			return respException(e);
		}
	} 

	private Response insertUsage() {
		String usage = "Inserts a new row into the content provider.\n";
		usage += "Following Parameters are supported:\n";
		usage += "a: defines the authority to query (required)\n";
		usage += "path0..n: elements of the path. Will be used to construct the URI as follows: content://a/path0/path1/../pathn\n";
		usage += "value0..n: values to be inserted into the content provider. The key/value pair is comma separated. E.g. value0=_id,6\n";
		return new Response(this.HTTP_OK, MIME_PLAINTEXT, usage);
	}
	
	private Response insert(Properties parms) {
		Uri uri = getUri(parms);
		if(uri == null) return insertUsage();
		try {
			String[] values = getArgs("value",parms);
			ContentValues cvs = new ContentValues();
			for(String v: values) {
				String[] pair = v.split(",");
				cvs.put(pair[0], pair[1]);
			}			
			Uri ret = this.cr.insert(uri, cvs);			
			String output = "rc: " + ret;
			return new Response(HTTP_OK, MIME_PLAINTEXT, output);
		} catch (Exception e) {
			return respException(e);
		}		
	}
	
	private Response read2Usage() {
		String usage = "Reads the content of a remote file descriptor using the openFileDescriptor(uri) method.\n";
		usage += "Following Parameters are supported:\n";
		usage += "a: defines the authority to query (required)\n";
		usage += "path0..n: elements of the path. Will be used to construct the URI as follows: content://a/path0/path1/../pathn\n";

		return new Response(this.HTTP_OK, MIME_PLAINTEXT, usage);
	}

	private Response read2(Properties parms) {
		Uri uri = getUri(parms);
		if(uri == null) return read2Usage();
		try {
				ParcelFileDescriptor fd = this.cr.openFileDescriptor(uri, "r");
				String output = "'" + fd.toString() + "', size: " + fd.getStatSize();
				return new Response(HTTP_OK, MIME_PLAINTEXT, output);
		} catch(Exception e) {
			return respException(e);
		}
	}
	
	private Response readUsage() {
		String usage = "Reads the content of a remote file descriptor using the openInputStream(uri) method.\n";
		usage += "Following Parameters are supported:\n";
		usage += "a: defines the authority to query (required)\n";
		usage += "path0..n: elements of the path. Will be used to construct the URI as follows: content://a/path0/path1/../pathn\n";

		return new Response(this.HTTP_OK, MIME_PLAINTEXT, usage);
	}

	private Response read(Properties parms) {
		Uri uri = getUri(parms);
		if(uri == null) return readUsage();
		try {			
			InputStream is = this.cr.openInputStream(uri);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int len = -1;
			do {
				byte[] buf = new byte[1024];
				len = is.read(buf);
				if(len>0) baos.write(buf, 0, len);
			} while(len != -1);
			byte[] buf = baos.toByteArray();
			String output="read " + buf.length + " bytes.\n\"";
			for(byte x: buf) output+= String.format("\\x%02X", x);
			output+="\"";  
			return new Response(HTTP_OK, MIME_PLAINTEXT, output);
		} catch (Exception e) {
			return respException(e);
		}
		
	}

	private Response list(Properties parms) {
		String output = "";		
		for (PackageInfo pack : pm.getInstalledPackages(PackageManager.GET_PROVIDERS)) {
	        ProviderInfo[] providers = pack.providers;
	        if (providers != null) {
	            for (ProviderInfo provider : providers) {
	            	output += "\n\npackage:\t" + provider.packageName;
	                output += "\nauthority:\t" + provider.authority;
	                output += "\nexported:\t" + provider.exported;
	                output += "\nreadPerm:\t" + provider.readPermission;
	                output += "\nwritePerm:\t" + provider.writePermission;
	                if(provider.pathPermissions != null) {
	                	int count = 0;
	                   	for(PathPermission perm :provider.pathPermissions) {
	                   		output += "\npathPerm" + count + ":\t" + perm.getPath();
	                   		output += "\nreadPerm" + count + ":\t" + perm.getReadPermission();
	                   		output += "\nwritePerm" + count + ":\t" + perm.getWritePermission();
	                   		count++;
	                   	}
	                }
	                output += "\n---------------------------------------------";
	            }
	        }
	    }
		return new Response(HTTP_OK, MIME_PLAINTEXT, output);

	}

	private Response queryUsage() {
		String usage = "Queries a content provider and prints the content of the returned cursor.";
		usage += "The query method looks as follows: ";		
		usage += "query (Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)\n";
		usage += "Following Parameters are supported:\n";
		usage += "a: defines the authority to query (required)\n";
		usage += "path0..n: elements of the path. Will be used to construct the URI as follows: content://a/path0/path1/../pathn\n";
		usage += "project0..n: elements in the projection array\n";
		usage += "selection: The selection argument.\n";
		usage += "selectionName, selectionId: Both need to be provided. Will be used to build a selection as follows selectionName+'='+selectionId. Will be used if no selection parameter is given.";
		usage += "arg0..n: elements of the selectionArgs array\n";
		usage += "sortOrder: the sortOrder argument";
		return new Response(this.HTTP_OK, MIME_PLAINTEXT, usage);
	}
	
	 
	private Response execQuery(Properties parms) {
		Response resp;
		Uri uri = getUri(parms);
		if(uri == null) return queryUsage();
		String[] projection = getArgs("project", parms);
		String selection = parms.getProperty("selection");
		if(selection == null) {
			String selectionName = parms.getProperty("selName");
			String selectionId = parms.getProperty("selId");
			if(selectionName != null && selectionId != null) {
				selection = selectionName + "=" + selectionId;
			}
		} 
		String[] selectionArgs = getArgs("arg",parms);
		String sortOrder = parms.getProperty("sortOrder");
		
		try {
			Cursor cur = cr.query(uri, projection, selection, selectionArgs, sortOrder);
			if(cur == null) {
				return new Response(this.HTTP_OK, MIME_PLAINTEXT, "no cursor was returned");
			}
			String output = "Query successful:\n";
			output += "Column count: " + cur.getColumnCount();
			output += "\nRow count: " + cur.getCount() + "\n";
			String[] colnames = cur.getColumnNames();
			for(String col: colnames) output +=  "|\t" + col + "\t";
			output += "\n";
			boolean next = cur.moveToFirst();
			while(next) {
				int x;
				for(x=0; x<cur.getColumnCount(); x++) output += "|\t" + cur.getString(x) + "\t";
				output += "\n";
				next = cur.moveToNext();
			}
			return new Response(this.HTTP_OK, MIME_PLAINTEXT, output);
		} catch(Exception e) {
			return respException(e);			
		}			
	}

	private Response respException(Exception e) {
		String output = "Exception: \n";
		output += e.toString() + "\n";
		output += e.getMessage() + "\n";
		Response resp = new Response(this.HTTP_OK, MIME_PLAINTEXT, output);
		return resp;
	}

	private Uri getUri(Properties parms) {
		String authority = parms.getProperty("a");
		if(authority == null) {
			return null;
		}
		String path = getPath(parms);
		Uri uri = Uri.parse("content://" + authority + path);
		return uri;
	}
	
	private String getPath(Properties parms) {
		int pathcount = 0;
		String path = "";
		String p;
		do {
			String next = "path" + pathcount;
			pathcount++;
			p = parms.getProperty(next);
			if(p != null) {
				path += "/" + p;
			}
		} while(p != null);
		return path;
	}
	
	private String[] getArgs(String name, Properties parms) {
		ArrayList<String> args = new ArrayList<String>();
		String arg;
		int argcount = 0;
		do {
			String next = name + argcount;
			argcount++;
			arg = parms.getProperty(next);
			if(arg != null) args.add(arg);
		} while(arg!=null);
		String[] strar = new String[args.size()];
		return (String[])args.toArray(strar);
	}

	private Response getInfo() {
		Response resp = new Response(HTTP_OK, MIME_PLAINTEXT, "Info: Android WebContentResolver ("+this.version+")");
		
		return resp;
	}
	
	private Response getUsage() {
		String usage = "<html><body><h1>Android WebContentResolver ("+this.version+"):</h1><br />";
		usage += "Provides a web service interface to Android content providers, in order to use web application testing capabilities and tools to test content providers.<br />";
		usage += "Following methods are supported:<br />";
		for(String h: quickhelp) {
			usage += h+"<br />";
		}
		usage+="<br />The content provider can be defined using the 'a' parameter.<br />";
		Response resp = new Response(HTTP_OK, this.MIME_HTML, usage);
		return resp;
	}
}
