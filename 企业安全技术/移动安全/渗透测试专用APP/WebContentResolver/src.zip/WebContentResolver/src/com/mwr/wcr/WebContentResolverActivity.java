// This tool is distributed under a BSD licence. A copy of this
// should have been included with this file.
//
// Copyright (c) 2011, nils


package com.mwr.wcr;

import java.io.IOException;

import android.app.Activity;
import android.content.ContentResolver;
import android.os.Bundle;
import android.widget.Toast;

public class WebContentResolverActivity extends Activity {
       
    ContentHTTPD httpd = null;
    
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int port = 8080;
        ContentResolver cr = this.getContentResolver();
        try {
        if(httpd == null) httpd = new ContentHTTPD(port, cr, this.getPackageManager());        
        } catch( IOException e) {
        	Toast.makeText(this.getApplicationContext(), "Failed to listen on port " + port, Toast.LENGTH_SHORT);
        }
        setContentView(R.layout.main);
    }
}